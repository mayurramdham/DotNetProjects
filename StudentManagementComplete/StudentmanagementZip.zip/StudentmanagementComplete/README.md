Resources and base Data https://chatgpt.com/c/66fed3a9-b434-8011-baed-579b81e2368e
