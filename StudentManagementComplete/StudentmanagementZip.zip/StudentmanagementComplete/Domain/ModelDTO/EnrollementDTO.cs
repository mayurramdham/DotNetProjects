﻿using Domain.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.ModelDTO
{
    public class EnrollementDTO
    {

        public int EnrollmentId { get; set; }
        public int StudentId { get; set; }
        //public Student Student { get; set; }
        public int CourseId { get; set; }
        //public Courses Courses { get; set; }
        public string Grade { get; set; }
    }
}
